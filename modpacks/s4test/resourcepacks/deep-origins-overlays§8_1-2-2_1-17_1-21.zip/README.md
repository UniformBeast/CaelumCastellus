![Deep Origins Overlays Pack](https://cdn.modrinth.com/data/cached_images/d916973cd020d1374a795f68e3d4e6a7588c4c58.png)

[![Available on CurseForge](https://cdn.modrinth.com/data/cached_images/0115db48e5f0f3e08ee5064bb15fb5d28f19558a.png)][CurseForge][![Available on Modrinth](https://media.forgecdn.net/attachments/description/976485/description_6b3c5758-9a6d-4923-989d-aebc2a32921f.png)][Modrinth][![Join my Discord Server !](https://media.forgecdn.net/attachments/description/976485/description_b744b3ca-b7a0-4a9a-82f0-f5f60e84ea19.png)][Discord]

![Requires OptiFine or Continuity](https://cdn.modrinth.com/data/cached_images/c839058144529911f09e6c3260f4f1a2dd9a07e6.png)

[![Download OptiFine](https://cdn.modrinth.com/data/cached_images/c9f6e7755ccff6b26440c946421cce156f37b88d.png)][OptiFine][![Download Continuity](https://cdn.modrinth.com/data/cached_images/fa9465e27ce45ec5b88079cd4dad5c03019fa989.png)][continuity]

### This is the source files of the latest version of Deep Origins Overlays, made by Devoneox
Feel free tu re-use this conctent in any of your projects, as long as you credit me and use the GNU GPLv3 license.

[CurseForge]:https://legacy.curseforge.com/minecraft/texture-packs/deep-origins-overlays
[Modrinth]:https://modrinth.com/resourcepack/deep-origins-overlays
[OptiFine]:https://optifine.net/downloads
[continuity]:https://modrinth.com/mod/continuity
[Discord]:https://discord.gg/Rma6zdg9zS
